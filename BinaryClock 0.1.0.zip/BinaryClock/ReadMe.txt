BinaryClock.exe
Created by Jkraghify on an uneventful night, October 2015
Displays a binary clock on the G keys of the Corsair K95 RGB.

Developed on Windows 10
Tested on two computers running Windows 10 connected to the NA K95 RGB
IDE: Microsoft Visual Studio 2013

**************
*INSTALLATION*
**************
  Download "BinaryClock X.X.X.zip" X.X.X applies to whatever version you are downloading.
  Unzip "BinaryClock X.X.X.zip" anywhere in your PC. The resulting files need to stay in the same directory in order to work.
  You may notice a file "BCSettings.txt". You can edit values in this file to change the colors of the LEDs.


If you come across a bug, please post about it in the Corsair User Forums Thread:
For feature requests, post in my Corsair User Forums Thread:
Keep in mind, I am not an advanced programmer. New features may or may not be implemented simply because I don't know enough C++
If you modify this code, feel free to share it. I ask you to please credit me in proportion to the code you borrowed. (i.e. "This program is a heavily modified version of the original Binary Clock created by Jkraghify. I optimised everything he couldn't, so basically it's an entirely new program")
